const Service = require('node-windows').Service;

const svc = new Service({
    name: 'unblock-netease-cloud-music',
    description: '点亮网易云音乐灰色歌曲',
    script: './app.js', // 入口文件路径
    // scriptOptions:'-p 52100:52101', // 可选参数示例: 自定义端口并开启HTTPS
    scriptOptions: '-o pyncmd kuwo bodian kugou migu ytdlp bilibili',
    wait: '1', // 程序崩溃后重启时间间隔
    grow: '0.25', // 重启等待时间成长值，第一次1秒，第二次1.25秒。。。
    maxRestarts: '40', // 60秒内最大重启次数
    env: [
        // {
        //     name: 'ENABLE_FLAC',
        //     value: 'true',
        // },
        {
            name: 'NETEASE_COOKIE',
            value: 'MUSIC_U=008FAF547E534F208A17884D1FB7C7E1A3A46BCAB2F186AA083B36120EB11374280EA60BB22416A4BC906D99D0841A6EF5D87D6DB1137A954BE57DDD33792088B6EA71FCE510C649B13285EE4F2FF974B7F697E32F881FB665F024B524E43F5CA7DD6A251ED5AB2ACFE0F1245EA1B86DA3ABB9B4687BCBCBFE5829B380C50C704CE4EB165D4617B5024F18F7A2C2D2248567DB4A6A7B52D2619BFDA56AD08DB707E2D0B2E8BA18BE3DBDC0EBC67A55AC0ABF389393F3CED04C5F92A3B7F14288790F198422592C9D61138CF8F8A762638A325ACAF3EAC91D17316FD0D1215B0062ADE036C03F95B95268B3E9037E49A4A901F2C8B4FC439C6F7C7A0E8AE1A9097CEE7791949D14B6F55D218521E4F8CBBA1942C894E7590B9F2F9B97629480F84021CCC80F59ABACA1E15273C0C01BA01D7ED5133E28FE49F8B3F98C6EBACCA4E153501F889304640CE4B77C0C363B332178B6F5798FBD450A95FC40880D76D9A1281574D1546A18327FAF0988171CACDB86B21680A6D15B88D1CCA181B29CEF4975328671C7E0CD2ADC12BC4090410671'
        },
        {
            name: 'DISABLE_UPGRADE_CHECK',
            value: 'DISABLE_UPGRADE_CHECK=true',
        }, {
            name: 'FOLLOW_SOURCE_ORDER',
            value: 'FOLLOW_SOURCE_ORDER=true',
        }
    ],
});

// 监听
svc.on('install', () => {
    svc.start();
    console.log('Installation completed.');
});
svc.on('uninstall', () => console.log('Uninstallation completed.'));

// 卸载
if (svc.exists) return svc.uninstall();

// 安装
svc.install();
